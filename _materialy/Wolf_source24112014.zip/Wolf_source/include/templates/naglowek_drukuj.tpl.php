<!DOCTYPE html>
<html>
<head>
	<title>PANELplus</title>
	<meta http-equiv="content-type" content="text/html;charset=utf-8" />
	<meta name="author" content="ARTplus">
	<meta name="robots" content="nofollow, noindex">
        <?php if($_GET['modul'] == 'certyfikaty'){ ?>
            <link href="css/certificate.css" rel="stylesheet" media="all">
        <?php } else { ?>
            <link href="css/print.css" rel="stylesheet" media="all">
        <?php } ?>
</head>
<body onload='window.focus();'>