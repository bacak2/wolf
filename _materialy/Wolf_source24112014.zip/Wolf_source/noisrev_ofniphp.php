<?php
/*echo date("Y-m-d M D H:i:s");
error_reporting(-1);
$vars = setlocale(LC_ALL, 'pl_PL.UTF-8');
var_dump($vars);*/
phpinfo();
?>