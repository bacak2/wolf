<?php
/**
 * Moduł elementów zlecenia
 * 
 * @author		Maciej Kura <Maciej.Kura@gmail.com>
 * @copyright           Copyright (c) 2012
 * @package		Panelplus
 * @version		1.0
 */
class ModulZestawienieZlecen extends ModulBazowy {
        public $OKs = false;
        public $Status = false;
        public $Companies = false;
        public $Users = false;
        
	function __construct(&$Baza, $Uzytkownik, $Parametr, $Sciezka) {
            parent::__construct($Baza, $Uzytkownik, $Parametr, $Sciezka);
            $this->Tabela = 'packages';
            $this->PoleID = 'id';
            $this->PoleSort = 'id';
            $this->SortHow = 'DESC';
            $this->PoleNazwy = 'title';
            $this->Nazwa = 'Zestawienie zleceń';
            $this->ModulyBezMenuBocznego[] = $this->Parametr;
            $this->Filtry[] = array('nazwa' => 'status', 'opis' => 'Status zlecenia', 'opcje' => Usefull::GetPackageStatuses($this->Uzytkownik->IsAdmin()), "typ" => "checkbox", 'col'=>'2', 'class'=>Usefull::GetTRClass('order'));
            $this->Filtry[] = array('opis' => true);
            $this->Filtry[] = array('nazwa' => 'happened_at', 'opis' => 'Data czynności', "typ" => "data_oddo" );
            $this->Filtry[] = array('nazwa' => 'sent_at', 'opis' => 'Data wysłania do WOLF', "typ" => "data_oddo" );
            $this->Filtry[] = array('nazwa' => 'p.company_id', 'opis' => 'Firma', 'opcje' => $this->GetCompanies(), "typ" => "lista", "domyslna" => "firma");
            $this->Filtry[] = array('nazwa' => 'type', 'opis' => 'Czynność', 'opcje' => $this->GetTypeActions(), "typ" => "lista", "domyslna" => "czynność", 'clear'=>true);
            $this->Filtry[] = array('nazwa' => "title|CONCAT(u.firstname,' ',u.surname)|p.id", 'opis' => false, "typ" => "tekst", "domyslna" => "", 'placeholder'=>'Szukaj zlecenia', 'search' => true);
            if($this->Uzytkownik->IsAdmin()){
                $this->DefaultFilters = array('status'=>array( 4,3 ) );
            }
            $this->CzySaOpcjeWarunkowe = true;
            if(isset($_GET['id']) && is_numeric($_GET['id'])){
                if($_GET['akcja'] == "element_szczegoly"){
                    $this->PackageID = $this->Baza->GetValue("SELECT package_id FROM items WHERE id = '{$_GET['id']}'");
                    if($this->ZablokujDostep($this->PackageID) == false){
                        $this->ZablokowaneElementyIDs['element_szczegoly'][] = $_GET['id'];
                    }
                }else if($this->ZablokujDostep($_GET['id']) == false){
                    $this->ZablokowaneElementyIDs['szczegoly'][] = $_GET['id'];
                    $this->ZablokowaneElementyIDs['edycja'][] = $_GET['id'];
                    $this->ZablokowaneElementyIDs['kasowanie'][] = $_GET['id'];
                }
            }
            $this->PrzyciskiFormularza['zapisz']['etykieta'] = "Dalej";
            $this->PrzyciskiFormularza['zapisz']['src'] = "arrow_right.gif";
            if(isset($_GET['akcja']) && $_GET['akcja'] == "dodawanie"){
                $this->FiltersAndActionsWidth = true;
            }
	}
        function PobierzListeElementow($Filtry = array()) {
            $Wyniki = array(
                    $this->PoleID => array('naglowek' => 'Id', 'td_styl' => 'width: 40px;'),
                    $this->PoleNazwy => array('naglowek' => 'Nazwa',  'td_styl' => 'width: 150px;'),
                    'invoice' =>  array('naglowek' => 'FV', 'elementy' => Usefull::GetCheckImg(), 'td_class' => 'active-check'),
                    'invoice_number' => array('naglowek' => 'Nr faktury'),
                    'status' => array('naglowek' => 'Status' ,'td_styl' => 'width: 100px;text-align: left;', "elementy" => Usefull::GetPackageStatuses($this->Uzytkownik->IsAdmin()), "class" => Usefull::GetPackageStatusesColor()),
                    'finalized_at' => array('naglowek' => 'Zakończono',  'td_styl' => 'width: 80px;'),
                    'client_name' => array('naglowek' => 'Użytkownik'),
                    'tr_class' =>  array( 'class' => Usefull::GetTRClass('order'), 'element_name' => 'expired'),
                    'tr_color' => (isset($_GET['selectid']) && is_numeric($_GET['selectid']) ? array( 'color' => array( $_GET['selectid'] => 'style="border: 2px solid #FFAAAA"'), 'element_name' => $this->PoleID ) : false),                );
                $Where = $this->GenerujWarunki();
                $Sort = $this->GenerujSortowanie();
                $max_opoznienie = intval($this->Baza->GetValue("SELECT value FROM settings WHERE id = 9")) - 1;
                $this->Baza->Query($this->QueryPagination("SELECT p.*, IF(DATEDIFF( NOW(), sent_at) > $max_opoznienie AND status IN(3,4), status, NULL ) as expired, CONCAT(u.firstname,' ',u.surname) as client_name, c.simplename
                                FROM $this->Tabela p
                                LEFT JOIN users u ON (u.id = p.user_id) 
                                LEFT JOIN companies c ON(c.id = p.company_id)
                                $Where $Sort", $this->ParametrPaginacji, 30));
                return $Wyniki;
	}

        function DomyslnyWarunek(){
            if($this->Uzytkownik->IsAdmin()){
                $domyslny = '';
            }else{
		$domyslny = ($this->Uzytkownik->CzyUprawniony() == false ? "p.user_id = '{$this->Uzytkownik->ZwrocIdUzytkownika()}'" : "p.company_id = '{$this->Uzytkownik->ZwrocInfo('company_id')}'");
            }
            return $domyslny;
        }

        function ZablokujDostep($ID) {
            if($this->Uzytkownik->IsAdmin()){
                return true;
            }
            $CheckAccess = $this->Baza->GetValue("SELECT count(p.$this->PoleID) FROM $this->Tabela p WHERE p.$this->PoleID = '$ID' AND {$this->DomyslnyWarunek()}");
            if($CheckAccess > 0){
                return true;
            }
            return false;
        }

        function GetCompanies(){
            if($this->Companies == false){
                $ModulFirmy = new ModulFirmy($this->Baza, $this->Uzytkownik, "test123", $this->Sciezka);
                $this->Companies = $ModulFirmy->GetList();
            }
            return $this->Companies;
        }

        function GetUsers(){
            if($this->Users == false){
                $ModulUzytkownicy = new ModulUzytkownicy($this->Baza, $this->Uzytkownik, $this->Parametr, $this->Sciezka);
                $this->Users = $ModulUzytkownicy->GetListWithCompanies();
            }
            return $this->Users;
        }

        function AkcjaLista($Filtry = array()) {
            ?><script type="text/javascript" src="js/plugins/jquery.qtip.js"></script><?php
            parent::AkcjaLista($Filtry);
        }
       
        function ObrobkaDanychLista($Elementy){
            foreach($Elementy as $ElementyKey => $Element){
                ob_start();
                include(SCIEZKA_SZABLONOW."tooltip-zlecenia.tpl.php");
                $tooltip = ob_get_contents();
                ob_clean();
                $Elementy[$ElementyKey]['tooltip_content'] = $tooltip;
            }
            return $Elementy;
        }        

        function GetActions($ID){
            $Dodawanie = array('link' => "?modul=$this->Parametr&akcja=dodawanie", 'class' => 'dodawanie', 'img' => 'add.gif', 'desc' => 'Dodaj zlecenie');
            $Lista = array('link' => "?modul=$this->Parametr&akcja=lista", 'class' => 'lista', 'img' => 'list.gif', 'desc' => 'Lista zleceń');

/*            
            if(!in_array($this->Parametr, $this->ModulyBezDodawania)){
                $Dodawanie = array('link' => "?modul=$this->Parametr&akcja=dodawanie", 'class' => 'dodawanie', 'img' => 'add.gif', 'desc' => 'Nowe zestawienie');
                $Akcje['lista'][] = $Dodawanie;
            }
            if($this->Uzytkownik->IsAdmin()){
                if($this->Status == 3){
                    if($this->WykonywanaAkcja == "szczegoly" && $this->Baza->GetValue("SELECT count(*) FROM items WHERE package_id = '$ID' AND approved = 1") > 0){
                        $Akcje['szczegoly'][] = array('link' => "javascript:AcceptPackage($ID)", 'class' => 'dodawanie', 'img' => 'accept.gif', 'desc' => 'Akceptuj');
                    }
                    $Akcje['szczegoly'][] = array('link' => "?modul=zlecenia&akcja=szczegoly&id=$ID&act=cancel", 'class' => 'usun', 'img' => 'cancel.gif', 'desc' => 'Zamknij');
                }
                if($this->Status == 4){
                    $Akcje['szczegoly'][] = array('link' => "?modul=zlecenia&akcja=szczegoly&id=$ID&act=revive", 'class' => 'usun', 'img' => 'accept_red.gif', 'desc' => 'Przywróć');
                }
            }
            if($this->Status < 3 || $this->Uzytkownik->IsAdmin()){
                $Akcje['szczegoly'][] = array('link' => "?modul=$this->Parametr&akcja=edycja&id=$ID&back=details", 'class' => 'drukowanie', 'img' => 'pencil.gif', 'desc' => 'Edycja');
            }else{
                 $this->ZablokowaneElementyIDs['edycja'][] = $_GET['id'];
            }
            $IleItems = $this->Baza->GetValue("SELECT count(*) FROM items WHERE package_id = '$ID'");
            if($this->Status <= 3 && $IleItems == 0){
                $Akcje['szczegoly'][] = array('link' => "?modul=$this->Parametr&akcja=kasowanie&id=$ID", 'class' => 'usun', 'img' => 'bin_empty.gif', 'desc' => 'Usuń');
            }else{
                $this->ZablokowaneElementyIDs['kasowanie'][] = $_GET['id'];
            }
            if(($this->Status == 0 || $this->Status == 1) && ($this->Uzytkownik->CzyUprawniony() && $IleItems > 0)){
                $Akcje['szczegoly'][] = array('link' => "javascript:SendPackage($ID)", 'class' => 'wyslij', 'img' => 'email.gif', 'desc' => 'Wyślij');
            }else if($this->Status == 0  && $IleItems > 0){
                $Akcje['szczegoly'][] = array('link' => "javascript:ReadyPackage($ID)", 'class' => 'gotowe', 'img' => 'tick_blue.gif', 'desc' => 'Gotowe');
            }
            $Akcje['szczegoly'][] = array('link' => "?modul=$this->Parametr&akcja=szczegoly&id=$ID&typ=drukuj\" target=\"_blank\"", 'class' => 'drukowanie', 'img' => 'printer.gif', 'desc' => 'Zestawienie');
            if($this->Status < 3 || $this->Uzytkownik->IsAdmin()){
                $Akcje['szczegoly'][] = array('link' => "?modul=items&akcja=dodaj_element&zlid=$ID", 'class' => 'dodawanie', 'img' => 'add.gif', 'desc' => 'Nowe zlecenie');
            }
               */ 
            $Akcje['akcja'] = array($Dodawanie, $Lista);
           
            return $Akcje;
        }        
        
    function GetTypeActions(){
        return array('SetupItem' => 'rozruch', 'WarrantyRepairItem' => 'naprawa gwarancyjna', 'WarrantyServiceItem' => 'przegląd gwarancyjny');
    }
}
?>