<script type='text/javascript' src='js/cookie-plugin.js'></script>
<script type="text/javascript">
    var cookieprefix = "<?php echo $this->cookie_prefix; ?>";
</script>
<script type='text/javascript' src='js/categories.js'></script>