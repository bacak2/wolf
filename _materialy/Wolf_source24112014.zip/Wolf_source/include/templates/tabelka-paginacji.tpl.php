<table class='paginacja_table'>
    <tr>
        <td>
            <?php Usefull::ShowPagination($this->LinkPodstawowy, $this->ParametrPaginacji, 15, $this->IleStronPaginacji); ?>
        </td>
    </tr>
</table>