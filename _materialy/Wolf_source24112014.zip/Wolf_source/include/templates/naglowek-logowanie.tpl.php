<!DOCTYPE html>
<html>
<head>
	<title>PANELplus - System zarządzania treścią</title>
	<meta http-equiv="content-type" content="text/html;charset=utf-8" />
	<meta name="author" content="ARTplus">
	<meta name="robots" content="nofollow, noindex">
        <link href="css/login.css" rel="stylesheet" media="screen">
        <link href="css/style.css" rel="stylesheet" media="screen">        
	<!--[if IE]>
		<link href="css/style-ie.css" rel="stylesheet" media="screen">
	<![endif]-->
</head>
<body>