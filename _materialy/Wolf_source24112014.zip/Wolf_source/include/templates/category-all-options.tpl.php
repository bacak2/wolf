<div class="options-all">
<span id="categories-expand-all">Rozwiń wszystkie</span>&nbsp;&nbsp;&nbsp;<span id="categories-collapse-all">Zwiń wszystkie</span>
</div>