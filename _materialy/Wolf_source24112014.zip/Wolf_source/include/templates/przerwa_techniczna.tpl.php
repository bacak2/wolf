<table width="100%" height="100%" border="0" cellspacing="0" cellpadding="0">
<tr><td align="center" valign="middle">
<table width="480" border="0" cellspacing="0" cellpadding="0" align="center">
	<tr>
		<td align="left" valign="top"><img src="images/top_logowanie.gif" alt="" height="43" width="480" border="0"></td>
	</tr>
	<tr>
		<td align="center" valign="middle" background="images/pasek_logowanie.gif">
			<p style='font-size: 12pt; font-weight: bold; margin: 20px;'>
			Przerwa techniczna.<br />
			<br />
			Prosimy spróbować później.<br />
			</p>
		</td>
	</tr>
	<tr>
		<td><img src="images/dol_logowanie.gif" alt="" height="26" width="480" border="0"></td>
	</tr>
	<tr>
		<td><p class="logowanie_dol">copyright  2004-2008 <a href="http://www.artplus.pl" target="_blank" class="log">ARTplus</a></td>
	</tr>
</table>
</td></tr>
</table>
