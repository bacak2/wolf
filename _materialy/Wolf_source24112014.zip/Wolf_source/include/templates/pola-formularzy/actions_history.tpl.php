<?php
$headers = array('type'=>'Czynność', 'happened_at'=>'Data zdarzenia','description'=>'Opis');
    foreach($headers as $Head){ ?>
        <div class="super-form-span3">
            <?php echo $Head; ?>
        </div>
    <?php }
    if(!empty($Wartosc ) && is_array($Wartosc))
        foreach($Wartosc as $Item)
            foreach($headers as $Head){ ?>
                <div class="super-form-span3">
                    <?php echo $Item[$Head]; ?>
                </div>
        <?php } ?>
