<?php
	$_SESSION['SID'] = session_id();
       $BazaParametry = array(
            'host' => 'mysql-wolfpolska.artplus24.pl',
            'schema' => 'db211619',
            'user' => 'db211619',
            'password' => 'qhIxs3X5cB'
        );
?>